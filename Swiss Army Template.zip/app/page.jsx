// Add these lines near the top with your other imports:
import { useState } from "react";

export default function HomePage() {
  // Keep the rest of your existing code...

  // 1. Create a new piece of state to track box color
  const [boxColor, setBoxColor] = useState("#ff0000");

  // 2. Function to pick a random color each time the button is clicked
  function handleColorChange() {
    const randomColor = "#" + Math.floor(Math.random() * 16777215).toString(16);
    setBoxColor(randomColor);
  }

  return (
    <div style={{ padding: 20 }}>
      {/* Your existing text and buttons stay here */}
      
      {/* Below your existing content, add this: */}
      <div
        style={{
          width: "100px",
          height: "100px",
          backgroundColor: boxColor,
          marginTop: "20px"
        }}
      />
      <button onClick={handleColorChange} style={{ marginTop: "10px" }}>
        Change Color
      </button>
    </div>
  );
}

