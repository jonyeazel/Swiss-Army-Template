export default function RootLayout({ children }) {
  return (
    <html lang="en">
      <head>
        <title>Swiss Army Template</title>
      </head>
      <body>{children}</body>
    </html>
  )
}



import './globals.css'

export const metadata = {
      generator: 'v0.dev'
    };
