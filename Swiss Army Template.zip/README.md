# Swiss Army Template

This is a Next.js 13 starter with:
- Supabase Auth
- Feature Flags
- Localization (i18n)
- AI Integration (Gaia)
- NFT/Web3
- Adaptive PDP Updates

## Quick Start
1. Clone the repo
2. Install dependencies
3. Add environment variables
4. Run `npm run dev` or `yarn dev`

## Deploy to Vercel
1. Push to GitHub
2. Link GitHub to Vercel
3. Add environment vars in Vercel
4. Deploy

