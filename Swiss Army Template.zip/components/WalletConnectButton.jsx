"use client"

export default function WalletConnectButton() {
  const handleConnect = () => {
    alert("Pretend we connected to a wallet!")
  }

  return <button onClick={handleConnect}>Connect Wallet</button>
}

